package main

import (
	"com.grpc.tleu/greet/greetpb"
	"fmt"
	"google.golang.org/grpc"
	"io"
	"log"
	"net"
	"time"
)

//Server with embedded UnimplementedGreetServiceServer
type Server struct {
	greetpb.UnimplementedGreetServiceServer
}


// GreetManyTimes is an example of stream from server side
func (s *Server) GreetManyTimes(req *greetpb.GreetManyTimesRequest, stream greetpb.GreetService_GreetManyTimesServer) error {
	fmt.Printf("GreetManyTimes function was invoked with %v \n", req)
	var num  = req.GetGreeting().GetNum()
	var count float32 = 2
	for num != 1 {

		if num / count == float32(int(num / count)){

			res := &greetpb.GreetManyTimesResponse{Result: count}
			if err := stream.Send(res); err != nil {
				log.Fatalf("error while sending greet many times responses: %v", err.Error())
			}
			time.Sleep(time.Second)
			num = num / count
		}else{
			count += 1
		}

	}
	return nil
}

//LongGreet is an example of stream from client side
func (s *Server) LongGreet(stream greetpb.GreetService_LongGreetServer) error {
	fmt.Printf("LongGreet function was invoked with a streaming request\n")
	var result float32 = 0
	var count float32 = 0

	for {
		req, err := stream.Recv()
		if err == io.EOF {
			// we have finished reading the client stream
			return stream.SendAndClose(&greetpb.LongGreetResponse{
				Result: result / count,
			})

		}
		if err != nil {
			log.Fatalf("Error while reading client stream: %v", err)
		}
		var num  = req.Greeting.GetNum()
		result += num
		count += 1
	}
}


func main() {
	l, err := net.Listen("tcp", "0.0.0.0:50051")
	if err != nil {
		log.Fatalf("Failed to listen:%v", err)
	}
	s := grpc.NewServer()
	greetpb.RegisterGreetServiceServer(s, &Server{})
	log.Println("Server is running on port:50051")
	if err := s.Serve(l); err != nil {
		log.Fatalf("failed to serve:%v", err)
	}
}
